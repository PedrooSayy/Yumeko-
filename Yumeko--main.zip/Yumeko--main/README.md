# Yumeko™
A Yumeko™ foi uma bot criada pelo ! ɪɪŞᴀʏʏʜ™#0005, ela não está 100% programada até por que o criador não é tão bom em programação...
o intuito desse bot é a diversão e moderação do seu server discord

espero que você goste da Yumeko™!! 
adicione já ela em seu server... está esperando oque?

const Discord = require('discord.js');

module.exports = {
    name: "shop",
    description: "Mostra a loja",

    async run (client, message, args) {

        const embed = new Discord.MessageEmbed()
        .setTitle('Lojinha')
        .setDescription(`Carro - 500 DemonCoins \n Relógio - 250 DemonCoins`)
        .setTimestamp();

        message.channel.send(embed);
    }
}
module.exports.run = async (client, message, args) => {
	if (!message.member.hasPermission('MANAGE_MESSAGES'))
		return message.reply(
			'Você é fraco, lhe falta permissão de `Gerenciar Mensagens` para usar esse comando...'
		);

	const amount = args[0] && !isNaN(args[0]) ? parseInt(args[0]) : 0;
	if (!amount || amount > 100) {
		return message.reply(
			'Por favor, forneça um número entre `1` e `100` para deletar rapidamente mensagens neste canal.'
		);
	}

	message.channel.bulkDelete(amount).then(deleted => {
		message.channel.send(`**foram deletadas ${deleted.size} mensagens!**`);
	});
};

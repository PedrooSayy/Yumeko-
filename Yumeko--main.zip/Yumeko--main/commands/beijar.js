const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://imgur.com/iclUiUN.gif',
  'https://imgur.com/lYQt9rx.gif',
  'https://imgur.com/w1TU5mR.gif',
  'https://i.imgur.com/OE7lSSY.gif',
  'https://i.imgur.com/0WWWvat.gif',
  'https://i.imgur.com/MGdlYsj.gif',
  'https://i.imgur.com/f86DzYb.gif',
  'https://i.imgur.com/YOQgZqY.gif',
  'https://i.imgur.com/s3DggdT.gif',
  'https://i.imgur.com/709chb9.gif',
  'https://i.imgur.com/KKP079r.gif',
  'https://i.imgur.com/RZ6myag.gif',
  'https://i.imgur.com/q8VV95J.gif',
  'https://i.imgur.com/P41mj1B.gif',
  'https://i.imgur.com/zGFB0wJ.gif',
  'https://i.imgur.com/dNOdjIz.gif',
  'https://i.imgur.com/PfHlW8s.gif',
  'https://i.imgur.com/TItLfqh.gif',
  'https://i.imgur.com/sGVgr74.gif',
  'https://i.imgur.com/YbNv10F.gif',
  'https://i.imgur.com/lmY5soG.gif',
  'https://i.imgur.com/KLVAl0T.gif',
  'https://i.imgur.com/KKAMPju.gif',
  'https://i.imgur.com/IgGumrf.gif',
  'https://i.imgur.com/eKcWCgS.gif',
  'https://i.imgur.com/uobBW9K.gif',
  'https://i.imgur.com/Uow8no2.gif',
  'https://i.imgur.com/I159BUo.gif',
  'https://i.imgur.com/8YZFU1Z.gif',
  'https://i.imgur.com/pDScNqs.gif',
  'https://i.imgur.com/gWIm5bK.gif',
  'https://i.imgur.com/Wc1Cqmc.gif',
  'https://i.imgur.com/1IuyOxK.gif',
  'https://i.imgur.com/nodEB4W.gif',
  'https://i.imgur.com/KSiA3Ws.gif',
  'https://i.imgur.com/GoJvaea.gif',
  'https://i.imgur.com/xELnNfC.gif',
  'https://i.imgur.com/gLyYxIK.gif',
  'https://i.imgur.com/nCwCS55.gif',
  'https://i.imgur.com/siVySzs.gif',
  'https://i.imgur.com/3aX4Qq2.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para beijar!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Beijo')
        .setColor('#8d3934')
        .setDescription(`${message.author} acaba de dar um beijo em ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Beijinhos')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}
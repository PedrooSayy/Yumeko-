const pagination = require('discord.js-pagination');
const Discord = require('discord.js');

module.exports = {
    name: "help",
    aliases: ["help","h","ajuda","comandos"],
    description: "O comando de ajuda... oque você esperava?",

    async run (client, message, args){

        //Créditos á ¡¡Şαyy™ ✘#0666 e Snow#3962 pelo comando

        const moderation = new Discord.MessageEmbed()
        .setTitle('<:Seta:764917200615637082> | Menu')
        .setColor('#8d3934')
        .addField('`m!kick`', 'Kicks a member from your server via mention or ID')
        .addField('`m!ban`', 'Bans a member from your server via mention or ID')
        .addField('`m!clear`', 'Purges messages')
        .setTimestamp()

        .setTitle('<a:1_:763215845417287681> | Moderação')
        .setColor('#8d3934')
        .addField('`m!kick`', 'Kicks a member from your server via mention or ID')
        .addField('`m!ban`', 'Bans a member from your server via mention or ID')
        .addField('`m!clear`', 'Purges messages')
        .setTimestamp()

        .setTitle('')
        .setColor('#8d3934')
        .addField('`m!kick`', 'Kicks a member from your server via mention or ID')
        .addField('`m!ban`', 'Bans a member from your server via mention or ID')
        .addField('`m!clear`', 'Purges messages')
        .setTimestamp()

        .setTitle('<a:1_:763215845417287681> | Moderação')
        .setColor('#8d3934')
        .addField('`m!kick`', 'Kicks a member from your server via mention or ID')
        .addField('`m!ban`', 'Bans a member from your server via mention or ID')
        .addField('`m!clear`', 'Purges messages')
        .setTimestamp()

        .setTitle('<a:1_:763215845417287681> | Moderação')
        .setColor('#8d3934')
        .addField('`m!kick`', 'Kicks a member from your server via mention or ID')
        .addField('`m!ban`', 'Bans a member from your server via mention or ID')
        .addField('`m!clear`', 'Purges messages')
        .setTimestamp()

        const fun = new Discord.MessageEmbed()
        .setTitle('<a:2_:763215905739374603> | Diversão')
        .setColor('#8d3934')
        .addField('`m!meme`', 'Generates a random meme')
        .addField('`m!ascii`', 'Converts text into ascii')
        .setTimestamp()

        const utility = new Discord.MessageEmbed()
        .setTitle('<a:3_:763215961411026985> | Utilidades')
        .setColor('#8d3934')
        .addField('`m!calculate`', )
        .addField('`m!ping`', 'Get the bot\'s API ping')
        .addField('`m!weather`', 'Checks weather forecast for provided location')
        .setTimestamp()

        const economy = new Discord.MessageEmbed()
        .setTitle('<a:4_:763216065940946975> | Economia')
        .setColor('#8d3934')
        .addField('`m!`', '-------------------')
        .addField('`m!`', '-------------------')
        .addField('`m!`', '-------------------')
        .setTimestamp()

        const pages = [
                moderation,
                fun,
                utility,
                economy
        ]

        const emojiList = ["⏪", "⏩"];

        const timeout = '120000';

        pagination(message, pages, emojiList, timeout)
    }
}
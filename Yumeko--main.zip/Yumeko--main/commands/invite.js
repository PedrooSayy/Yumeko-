const Discord = require('discord.js');

exports.run = async (client, message, args) => {
	var list = [];

	const embed = new Discord.MessageEmbed()
		.setTitle('Quer me adiconar no seu servidor?')
		.setColor('#8d3934')
		.setDescription('[Me adicione clicando aqui.](https://discord.com/oauth2/authorize?client_id=764568463985082418&scope=bot&permissions=805314622)');
	await message.channel.send(embed);
};

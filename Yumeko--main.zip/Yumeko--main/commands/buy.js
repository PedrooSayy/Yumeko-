const db = require('quick.db');
const Discord = require('discord.js');

module.exports = {
    name: "buy",
    description: "Compra algum item da loja",

    async run (client, message, args) {
        let purchase = args.join(" ");
        if(!purchase) return message.channel.send('Por favor, cite um item para comprá-lo')
        let items = await db.fetch(message.author.id, { items: [] });
        let amount = await db.fetch(`money_${message.guild.id}_${message.author.id}`)

        if(purchase === 'carro' || 'Carro'){
            if(amount < 500) return message.channel.send('Você não tem dinheiro suficiente para comprar este item. Por favor tente outro');
            db.subtract(`money_${message.guild.id}_${message.author.id}`, 500);
            db.push(message.author.id, "Carro");
            message.channel.send('Carro comprado com sucesso!')
        }
        if(purchase === 'relógio' || 'Relógio'){
            if(amount < 250) return message.channel.send('Você não tem dinheiro suficiente para comprar este item. Por favor tente outro');
            db.subtract(`money_${message.guild.id}_${message.author.id}`, 250);
            db.push(message.author.id, "Relógio");
            message.channel.send('Relógio comprado com sucesso!')
        }
    }
}